ASCEND WEBSITE - GITHUB PAGES READY

1. Unzip this folder.
2. Upload index.html and the assets folder to a GitHub repository.
3. Go to Settings > Pages.
4. Choose Deploy from branch > main > root.
5. Your website will go live for free.

Important:
Upload the files inside this folder, not the ZIP file itself.
